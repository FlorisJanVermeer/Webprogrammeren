	// Inloggen
	var i = 0;

function inloggen() {
	$("#loginform").effect("shake");
	var username = loginform.elements["username"].value;
	var password = loginform.elements["password"].value;
	var usernameArray = ["Hekman", "Koning", "ErikHekman", "ThijsWaardenburg", "Ronald", "RonaldVanEssen", "Floris"];
	
	for(var j = 0; j < usernameArray.length; j++) {
		if(username == usernameArray[j] && password == "Beta") {
			document.getElementById("demo").innerHTML
			location.href="timeline.html";
		}
	}

	if(username == "" && password == ""){
		document.getElementById("demo").innerHTML = ("U heeft geen gebruikersnaam en wachtwoord ingevuld!");
		$( "#demo" ).effect( "shake" )

		i++;
	}

	else if(username == ""){
		document.getElementById("demo").innerHTML = ("U heeft uw gebruikersnaam niet ingevuld.");
				$( "#demo" ).effect( "shake" )

		i++;
	}

	else if(password == ""){
		document.getElementById("demo").innerHTML = ("U heeft uw wachtwoord niet ingevuld.");
				$( "#demo" ).effect( "shake" )

		i++;
	}
	
	else{
		document.getElementById("demo").innerHTML = ("U heeft een onjuiste gebruikersnaam en/of wachtwoord ingevuld!");
		$( "#demo" ).effect( "shake" )

		i++;
	}

	if(i>2){
		document.getElementById("demo").innerHTML = ("U heeft 3x onjuiste gegevens ingevuld en kunt niet meer inloggen!");
		$("button").hide();
		$("input").prop('disabled', true);
	}
}


	// registreren
function registreren(){
	$( "#registerform" ).effect( "shake" );
		var vn = registerform.elements["vn"].value;
		var an = registerform.elements["an"].value;
		var gn = registerform.elements["gn"].value;
		var mail = registerform.elements["mail"].value;
		var ww = registerform.elements["ww"].value;
		var hww = registerform.elements["hww"].value;

		var valid = false;
		var gnOnbeschikbaar = false;
		var gnArray = ["Hekman", "Koning", "ErikHekman", "ThijsWaardenburg", "Ronald", "RonaldVanEssen", "Floris"];

		document.getElementById("demo2").innerHTML = "";

		for(var index=0; index < gnArray.length; index++){

			if(gn == gnArray[index]){
			gnOnbeschikbaar = true;
			break;
			}
		}
		if(vn == ""){
			valid = true
			$("#demo2").append('U heeft geen voornaam ingevuld! <br />');
		}
		if(an == ""){
			valid = true
			$("#demo2").append('U heeft geen achternaam ingevuld! <br />');
		}
		if(gn == ""){
			valid = true
			$("#demo2").append('U heeft geen gebruikersnaam ingevuld!<br />');
		}
		if(mail == ""){
			valid = true
			$("#demo2").append('U heeft geen e-mailadres ingevuld!<br />');
		}
		if(ww == ""){
			valid = true
			$("#demo2").append('U heeft geen wachtwoord ingevuld!<br />');
		}
		if(hww == ""){
			valid = true
			$("#demo2").append('Voer uw wachtwoord nogmaals in!<br />');
		}

		if(gnOnbeschikbaar == true){
			$("#demo2").append("Deze gebruikersnaam is al in gebruik!");
		}

		if(ww !== hww){
			$("#demo2").append('Uw wachtwoord komt niet overeen!<br />');
		}

		if(valid == false && gnOnbeschikbaar == false){
			location.href="timeline.html"
		}
	};



	// validatie wachtwoord
function checkPass(){

	var ww = document.getElementById('ww');
	var hww = document.getElementById('hww');

	var message = document.getElementById('confirmMessage');

	var goodColor = "#66cc66";
	var badColor = "#ff6666";


	if(ww.value == hww.value){

		hww.style.backgroundColor = goodColor;
		message.style.color = goodColor;
		message.innerHTML = "Wachtwoorden komen overeen!"
	}else{

		hww.style.backgroundColor = badColor;
		message.style.color = badColor;
		message.innerHTML = "Wachtwoorden komen niet overeen!"
	}
}  



	// profielfoto
$(document).ready(function(){
	
	
	function readURL(input) {
		if (input.files && input.files[0]) {
			var reader = new FileReader();

			reader.onload = function (e) {
				$('.profile-pic').attr('src', e.target.result);
			}

			reader.readAsDataURL(input.files[0]);
		}
	}

    $(".file-upload").on('change', function(){
        readURL(this);
    });
    
    $(".profile-pic").on('click', function() {
       $(".file-upload").click();
    });
});


	// omslagfoto
$(document).ready(function(){
	
	
	function readURL(input) {
		if (input.files && input.files[0]) {
			var reader = new FileReader();

			reader.onload = function (e) {
				$('.profile-pic2').attr('src', e.target.result);
			}

			reader.readAsDataURL(input.files[0]);
		}
	}

    $(".file-upload2").on('change', function(){
        readURL(this);
    });
    
    $(".profile-pic2").on('click', function() {
       $(".file-upload2").click();
    });
});



	// Vriendenlijst
$(document).ready(function(){
    $(".addvriend1").click(function(){
        $(".addvriend4").show();
        $(".addvriend1").hide();
    });
});

$(document).ready(function(){
    $(".addvriend2").click(function(){
        $(".addvriend5").show();
        $(".addvriend2").hide();
    });
});

$(document).ready(function(){
    $(".addvriend3").click(function(){
        $(".addvriend6").show();
        $(".addvriend3").hide();
    });
});

$(document).ready(function(){
    $(".addvriend4").click(function(){
        $(".addvriend4").hide();
    });
});

$(document).ready(function(){
    $(".addvriend5").click(function(){
        $(".addvriend5").hide();
    });
});

$(document).ready(function(){
    $(".addvriend6").click(function(){
        $(".addvriend6").hide();
    });
});

$(document).ready(function(){
    $(".addvriend7").click(function(){
        $(".addvriend7").hide();
    });
});

$(document).ready(function(){
    $(".addvriend8").click(function(){
        $(".addvriend8").hide();
    });
});
$(document).ready(function(){
    $(".addvriend9").click(function(){
        $(".addvriend9").hide();
    });
});
$(document).ready(function(){
    $(".addvriend10").click(function(){
        $(".addvriend10").hide();
    });
});
$(document).ready(function(){
    $(".addvriend11").click(function(){
        $(".addvriend11").hide();
    });
});
$(document).ready(function(){
    $(".addvriend12").click(function(){
        $(".addvriend12").hide();
    });
});


	// Berichten
$(document).ready(function(){

$(".addChatBericht").click(function() {
    var input = $("#inputChatBericht").val();
    
    var inputChatIsEmpty = $.trim($('#inputChatBericht').val());

    if(inputChatIsEmpty.length !== 0) {
        var chatbericht = "<div class='chatbericht_right'><div class='omschrijving'>Floris zegt: <br>"+input+"</div></div>";
        $("#berichtenvenster").append(chatbericht);

    $("#inputChatBericht").val('');
    $("#error").text('');
} else {
    $("#error").text('Het veld is niet ingevuld.');
}
});

});



// Timeline
$(document).ready(function(){


$(".addBericht").click(function() {
    var input = $("#inputBericht").val();

    var inputIsEmpty = $.trim($('#inputBericht').val());

    if(inputIsEmpty.length !== 0) {
        var bericht = "<div class='bericht'><div class='omschrijving'><p> Floris:</p>"+input+"</div><div class='waardering'><div class='likes'>0</div><div class=''><a href='#' class='removeBericht'>Verwijder bericht</a><button class='addLike'>Like</button></div></div><div class='addComments'><input type='text' class='inputComment' placeholder='Reageer op dit bericht ...'/><button class='addComment'>Reageer</button></div><div class='comments'></div>";
        $("#berichten").append(bericht);
    
    $("#inputBericht").val('');
    $("#error").text('');
} else {
    $("#error").text('Het veld is niet ingevuld.');
}
});


$("body").on("click", ".addLike", function(){
    var likes = $(this).parent().siblings(".likes").text();
    likes++;
    $(this).parent().siblings(".likes").text(likes);
});


$("body").on("click", ".addComment", function(){
    var input = $(this).siblings(".inputComment").val();

    var inputCommentIsEmpty = $.trim($(this).siblings(".inputComment").val());

    if(inputCommentIsEmpty.length !== 0) {
        var comment = "<div class='comment'><div class='message'>"+input+"</div><div class='commentControl'><a href='#' class='removeComment'>Verwijder comment</a></div></div>";
        $(this).parent().siblings(".comments").append(comment);

        $(this).siblings(".inputComment").val('');
        $("#error").text('');
    } else {
        $("#error").text('Het commentveld is niet ingevuld.');
    }
});             


$("body").on("click", "a.removeComment", function(){
    $(this).closest('.comment').remove();
});



$("body").on("click", "a.removeBericht", function(){
    $(this).closest('.bericht').remove();
});

    
});
